﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MINICACTPOT
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int[] nums = new int[10];
        int buttcon = 0;
        int winans = 0;
        public int[] prizes = new int[] { 0, 0, 0, 0, 0, 0, 10000, 36, 720, 360, 80, 252, 108, 72, 54, 180, 72, 180, 119, 36, 306, 1080, 144, 1800, 3600 };
        public MainWindow()
        {
            InitializeComponent();
        }

        private void START_Click(object sender, RoutedEventArgs e)
        {
            START.IsEnabled = false;
            int count = 0;
            foreach (int i in UniqueRandom(1, 9))
            {
                if (count < 10)
                {
                    
                    nums[count] = i;
                    count++;
                }
            }
            Main1.IsEnabled = true;
            Main2.IsEnabled = true;
            Main3.IsEnabled = true;
            Main4.IsEnabled = true;
            Main6.IsEnabled = true;
            Main7.IsEnabled = true;
            Main8.IsEnabled = true;
            Main9.IsEnabled = true;
            Main5.Content = nums[4];
        }

        private void buttconmethod()
        {
            if(buttcon == 3)
            {
                Main1.IsEnabled = false;
                Main2.IsEnabled = false;
                Main3.IsEnabled = false;
                Main4.IsEnabled = false;
                Main6.IsEnabled = false;
                Main7.IsEnabled = false;
                Main8.IsEnabled = false;
                Main9.IsEnabled = false;

                S1.IsEnabled = true;
                S2.IsEnabled = true;
                S3.IsEnabled = true;
                SW.IsEnabled = true;
                SE.IsEnabled = true;
                E1.IsEnabled = true;
                E2.IsEnabled = true;
                E3.IsEnabled = true;
            }
        }

        /// <summary>
        /// Returns all numbers, between min and max inclusive, once in a random sequence.
        /// </summary>
        IEnumerable<int> UniqueRandom(int minInclusive, int maxInclusive)
        {
            List<int> candidates = new List<int>();
            for (int i = minInclusive; i <= maxInclusive; i++)
            {
                candidates.Add(i);
            }
            Random rnd = new Random();
            while (candidates.Count > 0)
            {
                int index = rnd.Next(candidates.Count);
                yield return candidates[index];
                candidates.RemoveAt(index);
            }
        }

        private void wincon()
        {
            Main1.Content = nums[0];
            Main2.Content = nums[1];
            Main3.Content = nums[2];
            Main4.Content = nums[3];
            Main5.Content = nums[4];
            Main6.Content = nums[5];
            Main7.Content = nums[6];
            Main8.Content = nums[7];
            Main9.Content = nums[8];
            for (int x = 6; x < 25; x++)
            {
                if(x == winans)
                {
                    MessageBox.Show("You won " + prizes[x] + " casino credit!");
                }
            }
            S1.IsEnabled = false;
            S2.IsEnabled = false;
            S3.IsEnabled = false;
            SW.IsEnabled = false;
            SE.IsEnabled = false;
            E1.IsEnabled = false;
            E2.IsEnabled = false;
            E3.IsEnabled = false;

            Main1.IsEnabled = false;
            Main2.IsEnabled = false;
            Main3.IsEnabled = false;
            Main4.IsEnabled = false;
            Main6.IsEnabled = false;
            Main7.IsEnabled = false;
            Main8.IsEnabled = false;
            Main9.IsEnabled = false;

            Main1.Content = "";
            Main2.Content = "";
            Main3.Content = "";
            Main4.Content = "";
            Main5.Content = "";
            Main6.Content = "";
            Main7.Content = "";
            Main8.Content = "";
            Main9.Content = "";

            winans = 0;
            buttcon = 0;

            START.IsEnabled = true;
        }

        private void Main1_Click(object sender, RoutedEventArgs e)
        {
            Main1.Content = nums[0];
            buttcon++;
            buttconmethod();
        }

        private void Main2_Click(object sender, RoutedEventArgs e)
        {
            Main2.Content = nums[1];
            buttcon++;
            buttconmethod();
        }

        private void Main3_Click(object sender, RoutedEventArgs e)
        {
            Main3.Content = nums[2];
            buttcon++;
            buttconmethod();
        }

        private void Main4_Click(object sender, RoutedEventArgs e)
        {
            Main4.Content = nums[3];
            buttcon++;
            buttconmethod();
        }

        private void Main5_Click(object sender, RoutedEventArgs e)
        {
            Main5.Content = nums[4];
            buttcon++;
            buttconmethod();
        }

        private void Main6_Click(object sender, RoutedEventArgs e)
        {
            Main6.Content = nums[5];
            buttcon++;
            buttconmethod();
        }

        private void Main7_Click(object sender, RoutedEventArgs e)
        {
            Main7.Content = nums[6];
            buttcon++;
            buttconmethod();
        }

        private void Main8_Click(object sender, RoutedEventArgs e)
        {
            Main8.Content = nums[7];
            buttcon++;
            buttconmethod();
        }

        private void Main9_Click(object sender, RoutedEventArgs e)
        {
            Main9.Content = nums[8];
            buttcon++;
            buttconmethod();
        }

        private void SW_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[2] + nums[4] + nums[6];
            wincon();
        }

        private void S3_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[2] + nums[5] + nums[8];
            wincon();
        }

        private void S2_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[1] + nums[4] + nums[7];
            wincon();
        }

        private void S1_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[0] + nums[3] + nums[6];
            wincon();
        }

        private void SE_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[0] + nums[4] + nums[8];
            wincon();
        }

        private void E1_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[0] + nums[1] + nums[2];
            wincon();
        }

        private void E2_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[3] + nums[4] + nums[5];
            wincon();
        }

        private void E3_Click(object sender, RoutedEventArgs e)
        {
            winans = nums[6] + nums[7] + nums[8];
            wincon();
        }
    }
}
